import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  url:string='http://localhost:8081/staff/';
  

  constructor(private http:HttpClient) { }

  getAllStaffs()
  {
    return this.http.get(this.url);
  }

  findStaffById(staffId:any)
  {
    return this.http.get(this.url+staffId);
  }

  addStaff(staff:Observable<any>)
  {
    return this.http.post(this.url,staff);
  }

  modifyStaff(staff:any)
  {
    return this.http.put(this.url,staff);
  }
  deleteStaff(staffId:any)
  {
    return this.http.delete(this.url+staffId);
  }
  getSalary(designation:any)
  {
    return this.http.get(this.url+"staff/"+designation);
  }
 
}
