import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StaffService } from '../staff.service';


@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {

  staffForm: any;
  staffs: any;
  salary: any;
  

  
  constructor(private fb: FormBuilder, private bs: StaffService) {
    this.staffForm = this.fb.group({
      staffId: [''],
      userName: [''],
      dateOfJoining: [''],
      designation:[''],
      salary:['']
    });
  }




  ngOnInit(): void {
    
    this.getAllStaffs();
  }
  

  fnSalary(){

    var designation=this.staffForm.controls.designation.value;
    console.log(designation);
    this.bs.getSalary(designation).subscribe((data) => {
      console.log(data);
        var salary=data;
      this.staffForm.controls.salary.value=data;
      this.salary=salary;
      console.log(this.staffForm.controls.salary.value);
    });
  }

  getAllStaffs() {
    this.bs.getAllStaffs().subscribe((data) => {
      console.log(data);
      this.staffs = data;
    });
  }

  fnSelect(staffId) {
    this.bs.findStaffById(staffId).subscribe((data) => {
      console.log(data);
      
      this.staffForm.patchValue(data);
    });
  }


  fnFind() {
    var staffId = this.staffForm.controls.bid.value;
    this.fnSelect(staffId);
  }

  fnAdd() {
    var staff = this.staffForm.value;
    var designation=this.staffForm.designation.value;
      
    this.bs.addStaff(staff).subscribe((data) => {
      console.log(data);
    //  this.fnSalary(designation);
      this.getAllStaffs();

    });
  }
  fnModify() {
    var staff = this.staffForm.value;
    this.bs.modifyStaff(staff).subscribe((data) => {
      console.log(data);
      this.getAllStaffs();
    });
  }
  fnDelete() {
    var staffId = this.staffForm.controls.staffId.value;
    this.bs.deleteStaff(staffId).subscribe((data) => {
      console.log(data);
      this.getAllStaffs();
    });
  }

}
